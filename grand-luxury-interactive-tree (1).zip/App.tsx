import React, { useState, useEffect, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import Scene from './components/Scene';
import HandController, { HandGesture } from './components/HandController';
import { AppState } from './types';
import { COLORS } from './constants';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.FORMED);
  const [progress, setProgress] = useState(1);
  const [handOffset, setHandOffset] = useState({ x: 0, y: 0 });

  // Animation Loop for state transition
  useEffect(() => {
    let animationFrame: number;
    
    const animate = () => {
      setProgress((prev) => {
        // If state is FORMED or PHOTO_ZOOM, we want the tree to be formed (progress 1)
        // If state is CHAOS, we want explosion (progress 0)
        const target = appState === AppState.CHAOS ? 0 : 1;
        
        const delta = (target - prev) * 0.05; 
        
        if (Math.abs(target - prev) < 0.001) return target;
        return prev + delta;
      });
      animationFrame = requestAnimationFrame(animate);
    };
    
    animate();
    return () => cancelAnimationFrame(animationFrame);
  }, [appState]);

  // Hand Callbacks
  const handleGestureDetect = useCallback((gesture: HandGesture) => {
    setAppState(prevState => {
        if (gesture === HandGesture.OPEN) {
            return AppState.CHAOS;
        } else if (gesture === HandGesture.FIST) {
            return AppState.FORMED;
        } else if (gesture === HandGesture.PINCH) {
            // Only allow entering zoom if we were formed or already zoomed
            // If chaos, maybe pinch doesn't work? Let's allow it for cool effect.
            return AppState.PHOTO_ZOOM;
        }
        return prevState;
    });
  }, []);

  const handlePositionChange = useCallback((x: number, y: number) => {
    setHandOffset({ x, y });
  }, []);

  return (
    <div className="relative w-full h-screen bg-black overflow-hidden font-serif">
      {/* 3D Canvas */}
      <div className="absolute inset-0 z-0">
        <Canvas
          shadows
          dpr={[1, 2]}
          camera={{ position: [0, 4, 25], fov: 45 }}
          gl={{ antialias: false, toneMappingExposure: 1.2 }}
        >
          <color attach="background" args={[COLORS.EMERALD_DEEP]} />
          <Scene progress={progress} appState={appState} handOffset={handOffset} />
        </Canvas>
      </div>

      {/* Hand Controller (Webcam) */}
      <HandController 
        onGestureDetect={handleGestureDetect} 
        onPositionChange={handlePositionChange} 
      />

      {/* Luxury Overlay UI */}
      <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-between p-8 md:p-12">
        
        {/* Header */}
        <header className="flex flex-col items-center text-center animate-fade-in-down transition-opacity duration-500" style={{ opacity: appState === AppState.PHOTO_ZOOM ? 0 : 1 }}>
          <h1 className="text-4xl md:text-6xl text-transparent bg-clip-text bg-gradient-to-b from-[#FFF5C3] to-[#D4AF37] font-bold tracking-widest uppercase drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]" style={{ fontFamily: '"Playfair Display", serif' }}>
            The Grand Holiday
          </h1>
          <div className="h-px w-24 md:w-48 bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mt-4 mb-2"></div>
        </header>

        {/* Controls Guide */}
        <div className="flex flex-col items-center mb-8 pointer-events-auto">
             <div className="text-[#FFF5C3] text-sm mb-4 tracking-widest opacity-80 text-center space-y-1">
                <span className={appState === AppState.CHAOS ? "text-[#D4AF37] font-bold" : ""}>OPEN HAND: UNLEASH</span>
                <span className={appState === AppState.FORMED ? "text-[#D4AF37] font-bold" : ""}>FIST: ASSEMBLE</span>
                <span className={appState === AppState.PHOTO_ZOOM ? "text-[#D4AF37] font-bold" : ""}>PINCH: INSPECT MEMORY</span>
             </div>
            
            <div className="mt-4 text-[#FFF5C3] text-xs opacity-60 tracking-wider">
              {appState === AppState.PHOTO_ZOOM ? "MEMORY REVEALED" : `${Math.round(progress * 100)}% CONVERGENCE`}
            </div>
        </div>
      </div>
    </div>
  );
};

export default App;