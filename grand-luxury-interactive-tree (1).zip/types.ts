import * as THREE from 'three';

export enum AppState {
  CHAOS = 'CHAOS',
  FORMED = 'FORMED',
  PHOTO_ZOOM = 'PHOTO_ZOOM',
}

export interface DualPosition {
  chaos: THREE.Vector3;
  target: THREE.Vector3;
  color?: THREE.Color;
  scale?: number;
  rotation?: THREE.Euler;
}

export interface FoliageUniforms {
  uTime: { value: number };
  uProgress: { value: number };
  uColorPrimary: { value: THREE.Color };
  uColorSecondary: { value: THREE.Color };
}