import * as THREE from 'three';
import { CONFIG } from './constants';

// Helper to get a random point inside a sphere (Chaos state)
export const getRandomSpherePoint = (radius: number): THREE.Vector3 => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  const x = r * Math.sin(phi) * Math.cos(theta);
  const y = r * Math.sin(phi) * Math.sin(theta);
  const z = r * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
};

// Helper to get a point on a cone volume (Tree state)
// h: height position (0 to 1), r: max radius at bottom
export const getTreePoint = (height: number, maxRadius: number, yOffset: number): THREE.Vector3 => {
  const y = Math.random() * height; // Random height
  const progress = y / height; // 0 at bottom, 1 at top
  
  // Cone radius decreases as we go up
  const currentRadius = maxRadius * (1 - progress); 
  
  // Random angle
  const angle = Math.random() * Math.PI * 2;
  
  // Random distance from center (volume, not just surface)
  // Square root for uniform distribution
  const r = Math.sqrt(Math.random()) * currentRadius;
  
  const x = Math.cos(angle) * r;
  const z = Math.sin(angle) * r;
  
  return new THREE.Vector3(x, y + yOffset, z);
};
