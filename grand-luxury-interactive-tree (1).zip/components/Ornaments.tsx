import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG, ORNAMENT_TYPES } from '../constants';
import { getRandomSpherePoint, getTreePoint } from '../utils';

const tempObject = new THREE.Object3D();
const tempVec3 = new THREE.Vector3();

interface OrnamentsProps {
  progress: number; // 0 to 1
}

const Ornaments: React.FC<OrnamentsProps> = ({ progress }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  
  // Create data for all instances
  const instances = useMemo(() => {
    const data: any[] = [];
    
    for (let i = 0; i < CONFIG.ORNAMENT_COUNT; i++) {
      const type = ORNAMENT_TYPES[Math.floor(Math.random() * ORNAMENT_TYPES.length)];
      
      // Chaos Pos
      const startPos = getRandomSpherePoint(20); // Wider chaos radius for ornaments
      
      // Target Pos - Surface of cone mostly
      // To put them on surface: r = maxR * (1-h) exactly (minus a little variance)
      const h = Math.random() * CONFIG.TREE_HEIGHT;
      const hNorm = h / CONFIG.TREE_HEIGHT;
      const rCone = CONFIG.TREE_RADIUS * (1 - hNorm);
      const angle = Math.random() * Math.PI * 2;
      
      const x = Math.cos(angle) * rCone;
      const z = Math.sin(angle) * rCone;
      const y = h - (CONFIG.TREE_HEIGHT / 2);

      const targetPos = new THREE.Vector3(x, y, z);
      
      // Color
      const colorHex = type.colors[Math.floor(Math.random() * type.colors.length)];
      const color = new THREE.Color(colorHex);

      data.push({
        startPos,
        targetPos,
        currentPos: startPos.clone(),
        scale: type.scale * (0.8 + Math.random() * 0.4),
        speed: type.weight, // Used for lerp alpha
        color,
        rotation: new THREE.Euler(Math.random()*Math.PI, Math.random()*Math.PI, 0)
      });
    }
    return data;
  }, []);

  useLayoutEffect(() => {
    if (meshRef.current) {
      instances.forEach((data, i) => {
        meshRef.current!.setColorAt(i, data.color);
      });
      meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [instances]);

  useFrame(() => {
    if (!meshRef.current) return;

    // Manual interpolation for "physics" feel based on weight
    const targetProgress = progress;

    instances.forEach((data, i) => {
      // Determine destination based on progress
      // We want to lerp currentPos towards the desired state point
      // If progress is 1, we want targetPos. If 0, startPos.
      
      // Calculate where this specific particle WANTS to be right now globally
      tempVec3.copy(data.startPos).lerp(data.targetPos, targetProgress);
      
      // Move current position towards that global target point
      // Using 'speed' allows lighter objects to snap faster, heavy ones lag behind
      data.currentPos.lerp(tempVec3, data.speed);

      tempObject.position.copy(data.currentPos);
      tempObject.rotation.copy(data.rotation);
      tempObject.scale.setScalar(data.scale);
      
      // Gentle rotation for formed tree
      if (targetProgress > 0.9) {
          tempObject.rotation.y += 0.01;
      }

      tempObject.updateMatrix();
      meshRef.current!.setMatrixAt(i, tempObject.matrix);
    });

    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[undefined, undefined, CONFIG.ORNAMENT_COUNT]}
      castShadow
      receiveShadow
    >
      <sphereGeometry args={[1, 32, 32]} />
      <meshStandardMaterial 
        roughness={0.1} 
        metalness={0.9} 
        envMapIntensity={2.5}
      />
    </instancedMesh>
  );
};

export default Ornaments;
