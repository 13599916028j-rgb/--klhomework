import React, { useEffect, useRef, useState } from 'react';
import { FilesetResolver, HandLandmarker } from "@mediapipe/tasks-vision";

export enum HandGesture {
  NONE = 'NONE',
  OPEN = 'OPEN',
  FIST = 'FIST',
  PINCH = 'PINCH'
}

interface HandControllerProps {
  onGestureDetect: (gesture: HandGesture) => void;
  onPositionChange: (x: number, y: number) => void;
}

const HandController: React.FC<HandControllerProps> = ({ onGestureDetect, onPositionChange }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [loaded, setLoaded] = useState(false);
  const [currentGesture, setCurrentGesture] = useState<HandGesture>(HandGesture.NONE);

  useEffect(() => {
    let handLandmarker: HandLandmarker | null = null;
    let animationFrameId: number;
    let lastVideoTime = -1;

    const setupMediaPipe = async () => {
      // Use specific version matching index.html to prevent loading freeze
      const vision = await FilesetResolver.forVisionTasks(
        "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.8/wasm"
      );

      handLandmarker = await HandLandmarker.createFromOptions(vision, {
        baseOptions: {
          modelAssetPath: "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
          delegate: "GPU"
        },
        runningMode: "VIDEO",
        numHands: 1,
        minHandDetectionConfidence: 0.5,
        minHandPresenceConfidence: 0.5,
        minTrackingConfidence: 0.5
      });

      startWebcam();
    };

    const startWebcam = () => {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: 320, // Low res for performance
                    height: 240,
                    frameRate: { ideal: 30 }
                } 
            }).then((stream) => {
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    videoRef.current.addEventListener("loadeddata", predictWebcam);
                    setLoaded(true);
                }
            }).catch(err => {
                console.error("Camera access denied or failed", err);
            });
        }
    };

    const predictWebcam = () => {
      if (videoRef.current && handLandmarker) {
        // Only detect if video time has advanced
        if (videoRef.current.currentTime !== lastVideoTime) {
            lastVideoTime = videoRef.current.currentTime;
            const startTimeMs = performance.now();
            const result = handLandmarker.detectForVideo(videoRef.current, startTimeMs);
            
            if (result.landmarks && result.landmarks.length > 0) {
                const landmarks = result.landmarks[0];
                const wrist = landmarks[0];
                
                // --- Gesture Logic ---
                const tips = [4, 8, 12, 16, 20]; 
                let totalDist = 0;
                tips.forEach(idx => {
                    const tip = landmarks[idx];
                    const dist = Math.sqrt(
                        Math.pow(tip.x - wrist.x, 2) + 
                        Math.pow(tip.y - wrist.y, 2) + 
                        Math.pow(tip.z - wrist.z, 2)
                    );
                    totalDist += dist;
                });
                const avgDist = totalDist / tips.length;

                const thumbTip = landmarks[4];
                const indexTip = landmarks[8];
                const pinchDist = Math.sqrt(
                     Math.pow(thumbTip.x - indexTip.x, 2) + 
                     Math.pow(thumbTip.y - indexTip.y, 2) + 
                     Math.pow(thumbTip.z - indexTip.z, 2)
                );

                let detected = HandGesture.OPEN;

                if (avgDist < 0.2) { // Adjusted threshold
                    detected = HandGesture.FIST;
                } else if (pinchDist < 0.05) {
                    detected = HandGesture.PINCH;
                } else {
                    detected = HandGesture.OPEN;
                }

                if (detected !== currentGesture) {
                    setCurrentGesture(detected);
                    onGestureDetect(detected);
                }

                // --- Position Logic ---
                let avgX = 0;
                let avgY = 0;
                landmarks.forEach(lm => {
                    avgX += lm.x;
                    avgY += lm.y;
                });
                avgX /= landmarks.length;
                avgY /= landmarks.length;

                // Normalize: center is 0,0. Range -1 to 1.
                onPositionChange((avgX - 0.5) * 2, (avgY - 0.5) * 2);
            }
        }
        animationFrameId = window.requestAnimationFrame(predictWebcam);
      }
    };

    setupMediaPipe();

    return () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
            tracks.forEach(track => track.stop());
        }
        if (handLandmarker) {
            handLandmarker.close();
        }
        cancelAnimationFrame(animationFrameId);
    };
  }, [onGestureDetect, onPositionChange, currentGesture]);

  return (
    <div className="absolute bottom-4 right-4 z-50 opacity-80 hover:opacity-100 transition-opacity">
        <div className="relative border-2 border-[#D4AF37] rounded-lg overflow-hidden shadow-[0_0_15px_rgba(212,175,55,0.3)] bg-black/50">
            {!loaded && <div className="absolute inset-0 flex items-center justify-center text-[#D4AF37] text-xs">Init AI...</div>}
            <video 
                ref={videoRef} 
                className="w-32 h-24 object-cover -scale-x-100" 
                autoPlay 
                playsInline
                muted
            />
        </div>
        <div className="bg-black/80 mt-1 p-1 rounded text-center">
            <p className="text-[10px] text-[#D4AF37] uppercase tracking-wider">{currentGesture}</p>
        </div>
    </div>
  );
};

export default HandController;