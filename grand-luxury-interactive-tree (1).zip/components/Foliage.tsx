import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG, COLORS } from '../constants';
import { getRandomSpherePoint, getTreePoint } from '../utils';

// Custom Shader for high-performance interpolation
const FoliageShaderMaterial = {
  uniforms: {
    uTime: { value: 0 },
    uProgress: { value: 0 }, // 0 = Chaos, 1 = Formed
    uColorDeep: { value: new THREE.Color(COLORS.EMERALD_DEEP) },
    uColorLight: { value: new THREE.Color(COLORS.EMERALD_LIGHT) },
    uColorGold: { value: new THREE.Color(COLORS.GOLD_HIGHLIGHT) },
  },
  vertexShader: `
    uniform float uTime;
    uniform float uProgress;
    attribute vec3 aTargetPos;
    attribute float aRandom;
    
    varying vec2 vUv;
    varying float vRandom;
    varying float vDepth;

    // Cubic ease out function for smoother transition in shader
    float easeOutCubic(float x) {
      return 1.0 - pow(1.0 - x, 3.0);
    }

    void main() {
      vUv = uv;
      vRandom = aRandom;

      // Add some noise to the progress based on particle index for organic movement
      float localProgress = smoothstep(0.0, 1.0, uProgress);
      
      // Interpolate position
      vec3 pos = mix(position, aTargetPos, localProgress);
      
      // Add subtle wind/sparkle movement
      pos.x += sin(uTime * 2.0 + aRandom * 10.0) * 0.05 * localProgress;
      pos.z += cos(uTime * 1.5 + aRandom * 10.0) * 0.05 * localProgress;

      vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
      gl_Position = projectionMatrix * mvPosition;
      
      // Size attenuation
      gl_PointSize = (4.0 * aRandom + 2.0) * (10.0 / -mvPosition.z);
      
      vDepth = -mvPosition.z;
    }
  `,
  fragmentShader: `
    uniform vec3 uColorDeep;
    uniform vec3 uColorLight;
    uniform vec3 uColorGold;
    
    varying float vRandom;
    
    void main() {
      // Circular particle
      vec2 center = gl_PointCoord - 0.5;
      float dist = length(center);
      if (dist > 0.5) discard;

      // Mix colors based on randomness
      vec3 finalColor = mix(uColorDeep, uColorLight, vRandom);
      
      // Add occasional gold sparkles (10% of particles)
      if (vRandom > 0.9) {
        finalColor = uColorGold;
      }

      gl_FragColor = vec4(finalColor, 1.0);
    }
  `
};

interface FoliageProps {
  progress: number;
}

const Foliage: React.FC<FoliageProps> = ({ progress }) => {
  const materialRef = useRef<THREE.ShaderMaterial>(null);

  // Generate Geometry Data once
  const { positions, targetPositions, randoms } = useMemo(() => {
    const count = CONFIG.FOLIAGE_COUNT;
    const posArray = new Float32Array(count * 3);
    const targetPosArray = new Float32Array(count * 3);
    const randomArray = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      // Chaos Position (Sphere)
      const chaos = getRandomSpherePoint(15);
      posArray[i * 3] = chaos.x;
      posArray[i * 3 + 1] = chaos.y;
      posArray[i * 3 + 2] = chaos.z;

      // Target Position (Tree Cone)
      const target = getTreePoint(CONFIG.TREE_HEIGHT, CONFIG.TREE_RADIUS, -CONFIG.TREE_HEIGHT / 2);
      targetPosArray[i * 3] = target.x;
      targetPosArray[i * 3 + 1] = target.y;
      targetPosArray[i * 3 + 2] = target.z;

      randomArray[i] = Math.random();
    }

    return {
      positions: posArray,
      targetPositions: targetPosArray,
      randoms: randomArray
    };
  }, []);

  useFrame((state) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.getElapsedTime();
      // Smooth interpolation of the uniform
      materialRef.current.uniforms.uProgress.value = THREE.MathUtils.lerp(
        materialRef.current.uniforms.uProgress.value,
        progress,
        0.05 // Shader lerp speed
      );
    }
  });

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aTargetPos"
          count={targetPositions.length / 3}
          array={targetPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aRandom"
          count={randoms.length}
          array={randoms}
          itemSize={1}
        />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        attach="material"
        args={[FoliageShaderMaterial]}
        transparent={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

export default Foliage;
