import React, { useMemo, useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG, COLORS } from '../constants';
import { getRandomSpherePoint } from '../utils';

const tempObject = new THREE.Object3D();
const tempVec3 = new THREE.Vector3();
const tempTargetQuat = new THREE.Quaternion();

interface PhotosProps {
  progress: number;
  isZoomed: boolean;
  handOffset: { x: number, y: number };
}

// Generate a texture for the photos (Shared across instances)
const createPhotoTexture = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 320; 
    const ctx = canvas.getContext('2d')!;
    
    ctx.fillStyle = '#FAFAFA';
    ctx.fillRect(0, 0, 256, 320);
    
    ctx.fillStyle = '#111';
    ctx.fillRect(20, 20, 216, 216);

    const grad = ctx.createLinearGradient(20, 20, 236, 236);
    grad.addColorStop(0, '#D4AF37');
    grad.addColorStop(1, '#8a0000');
    ctx.fillStyle = grad;
    ctx.fillRect(20, 20, 216, 216);
    
    ctx.fillStyle = 'rgba(255,255,255,0.2)';
    ctx.beginPath();
    ctx.arc(100, 80, 50, 0, Math.PI * 2);
    ctx.fill();

    return new THREE.CanvasTexture(canvas);
};

const Photos: React.FC<PhotosProps> = ({ progress, isZoomed, handOffset }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const texture = useMemo(() => createPhotoTexture(), []);
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);

  // Initialize Data
  const instances = useMemo(() => {
    const data: any[] = [];
    for (let i = 0; i < CONFIG.PHOTO_COUNT; i++) {
        const startPos = getRandomSpherePoint(18);
        
        const h = Math.random() * (CONFIG.TREE_HEIGHT - 2) + 1; 
        const hNorm = h / CONFIG.TREE_HEIGHT;
        const rCone = CONFIG.TREE_RADIUS * (1 - hNorm) + 0.5; 
        const angle = Math.random() * Math.PI * 2;
        
        const x = Math.cos(angle) * rCone;
        const z = Math.sin(angle) * rCone;
        const y = h - (CONFIG.TREE_HEIGHT / 2);

        const targetPos = new THREE.Vector3(x, y, z);
        
        // Orientation: Face outwards from center
        const lookAtPos = new THREE.Vector3(x * 2, y, z * 2);
        
        // Calculate initial rotation towards lookAtPos
        tempObject.position.copy(targetPos);
        tempObject.lookAt(lookAtPos);
        const targetRot = tempObject.quaternion.clone();

        data.push({
            startPos,
            targetPos,
            lookAtPos,
            currentPos: startPos.clone(),
            currentQuat: new THREE.Quaternion().random(), // Start random rotation in chaos
            treeQuat: targetRot,
            scale: 0.8 + Math.random() * 0.4
        });
    }
    return data;
  }, []);

  useEffect(() => {
    if (isZoomed) {
        const index = Math.floor(Math.random() * CONFIG.PHOTO_COUNT);
        setActivePhotoIndex(index);
    }
  }, [isZoomed]);

  useFrame((state) => {
    if (!meshRef.current) return;

    instances.forEach((data, i) => {
        let targetPos: THREE.Vector3;
        let targetScale = data.scale;
        
        // --- 1. Position & Target Rotation Calculation ---
        if (isZoomed && i === activePhotoIndex) {
            // Move to camera
            targetPos = new THREE.Vector3(0, 4, 18);
            targetPos.x += handOffset.x * 2;
            targetPos.y += -handOffset.y * 2;
            targetScale = 3.0;
            
            // Look at camera
            tempObject.position.copy(data.currentPos);
            tempObject.lookAt(state.camera.position);
            tempTargetQuat.copy(tempObject.quaternion);
        } else {
            // Chaos <-> Tree
            tempVec3.copy(data.startPos).lerp(data.targetPos, progress);
            targetPos = tempVec3;
            
            if (progress < 0.1) {
                // In chaos, rotate randomly/continuously
                tempTargetQuat.copy(data.currentQuat).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0), 0.02));
            } else {
                // On tree, align to tree surface
                tempTargetQuat.copy(data.treeQuat);
            }
        }

        // --- 2. Smooth Interpolation ---
        // Position Lerp
        data.currentPos.lerp(targetPos, 0.08);
        
        // Rotation Slerp (Spherical Linear Interpolation) - Critical for smooth rotation
        data.currentQuat.slerp(tempTargetQuat, 0.08);

        // Scale Lerp
        const currentScale = tempObject.scale.x; 
        const nextScale = THREE.MathUtils.lerp(currentScale, targetScale, 0.08);
        
        // --- 3. Apply to Matrix ---
        tempObject.position.copy(data.currentPos);
        tempObject.quaternion.copy(data.currentQuat);
        tempObject.scale.setScalar(nextScale);

        tempObject.updateMatrix();
        meshRef.current!.setMatrixAt(i, tempObject.matrix);
    });
    
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[undefined, undefined, CONFIG.PHOTO_COUNT]}
      castShadow
      receiveShadow
    >
      <boxGeometry args={[1, 1.25, 0.05]} />
      <meshStandardMaterial 
        map={texture}
        roughness={0.2}
        metalness={0.1}
        color={COLORS.WHITE_SILK}
      />
    </instancedMesh>
  );
};

export default Photos;