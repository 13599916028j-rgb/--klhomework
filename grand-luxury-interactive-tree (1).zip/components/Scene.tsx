import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Environment, OrbitControls, Stars, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import * as THREE from 'three';
import Foliage from './Foliage';
import Ornaments from './Ornaments';
import Photos from './Photos';
import TopStar from './TopStar';
import { CONFIG, COLORS } from '../constants';
import { AppState } from '../types';

interface SceneProps {
  progress: number;
  appState: AppState;
  handOffset: { x: number, y: number };
}

const Scene: React.FC<SceneProps> = ({ progress, appState, handOffset }) => {
  const controlsRef = useRef<any>(null);

  // Smoothly interpolate camera angle based on hand position
  useFrame((state, delta) => {
    if (controlsRef.current) {
      // If we are in ZOOM mode, we might want to lock camera or center it
      // But for now, we let the hand adjust it slightly for parallax
      
      const defaultPolar = Math.PI / 2.2; 
      const defaultAzimuth = 0;

      // In Chaos/Open state or Zoom, we allow more rotation. 
      // In Formed state, we also allow it but maybe less? Sticking to consistent behavior.
      
      const targetAzimuth = defaultAzimuth + (handOffset.x * 1.5); 
      const targetPolar = defaultPolar + (handOffset.y * 0.5);

      const smoothing = 2.0 * delta;
      
      controlsRef.current.setAzimuthalAngle(
         THREE.MathUtils.lerp(controlsRef.current.getAzimuthalAngle(), targetAzimuth, smoothing)
      );
      
      controlsRef.current.setPolarAngle(
         THREE.MathUtils.lerp(controlsRef.current.getPolarAngle(), targetPolar, smoothing)
      );
      
      controlsRef.current.update();
    }
  });

  return (
    <>
      <OrbitControls 
        ref={controlsRef}
        enablePan={false} 
        enableZoom={false}
        minPolarAngle={Math.PI / 4} 
        maxPolarAngle={Math.PI / 1.8}
        minDistance={10}
        maxDistance={35}
        makeDefault 
      />

      {/* Lighting Setup */}
      <ambientLight intensity={0.2} color={COLORS.EMERALD_DEEP} />
      <spotLight 
        position={[10, 20, 10]} 
        angle={0.2} 
        penumbra={1} 
        intensity={2} 
        color={COLORS.GOLD_HIGHLIGHT} 
        castShadow 
      />
      <pointLight position={[-10, 5, -10]} intensity={1} color="#ffffff" />
      
      {/* HDRI Environment */}
      <Environment preset="lobby" />

      {/* Background Ambience */}
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      <Sparkles count={200} scale={12} size={2} speed={0.4} opacity={0.5} color={COLORS.GOLD_HIGHLIGHT} />

      <group rotation={[0, 0, 0]}>
        <Foliage progress={progress} />
        <Ornaments progress={progress} />
        <Photos 
            progress={progress} 
            isZoomed={appState === AppState.PHOTO_ZOOM} 
            handOffset={handOffset}
        />
        <TopStar />
      </group>

      {/* Cinematic Post Processing */}
      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={CONFIG.BLOOM_THRESHOLD} 
          mipmapBlur 
          intensity={CONFIG.BLOOM_INTENSITY} 
          radius={0.6}
        />
        <Vignette eskil={false} offset={0.1} darkness={1.1} />
      </EffectComposer>
    </>
  );
};

export default Scene;