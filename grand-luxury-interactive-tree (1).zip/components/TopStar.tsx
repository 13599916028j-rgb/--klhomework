import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { COLORS, CONFIG } from '../constants';

const TopStar: React.FC = () => {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      // Floating animation
      groupRef.current.position.y = (CONFIG.TREE_HEIGHT / 2 + 1.5) + Math.sin(state.clock.getElapsedTime()) * 0.2;
      // Gentle rotation
      groupRef.current.rotation.y += 0.01;
      groupRef.current.rotation.z = Math.sin(state.clock.getElapsedTime() * 0.5) * 0.1;
    }
  });

  // Create a snowflake shape using multiple boxes
  const armLength = 1.2;
  const armWidth = 0.15;
  const armDepth = 0.05;

  return (
    <group ref={groupRef} position={[0, CONFIG.TREE_HEIGHT / 2 + 1.5, 0]}>
      {/* Glow effect sprite */}
      <mesh>
        <sphereGeometry args={[0.5, 16, 16]} />
        <meshBasicMaterial color={COLORS.GOLD_HIGHLIGHT} transparent opacity={0.8} />
      </mesh>
      
      {/* Snowflake Structure */}
      {[0, 60, 120].map((angle, i) => (
        <group key={i} rotation={[0, 0, THREE.MathUtils.degToRad(angle)]}>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[armWidth, armLength * 2, armDepth]} />
            <meshStandardMaterial 
              color={COLORS.GOLD_METALLIC} 
              metalness={1} 
              roughness={0.1} 
              emissive={COLORS.GOLD_HIGHLIGHT}
              emissiveIntensity={0.5}
            />
          </mesh>
           {/* Detailed tips */}
          <mesh position={[0, armLength * 0.6, 0]} rotation={[0, 0, Math.PI / 4]}>
             <boxGeometry args={[armWidth, 0.5, armDepth]} />
             <meshStandardMaterial color={COLORS.GOLD_METALLIC} metalness={1} roughness={0.1} />
          </mesh>
          <mesh position={[0, armLength * 0.6, 0]} rotation={[0, 0, -Math.PI / 4]}>
             <boxGeometry args={[armWidth, 0.5, armDepth]} />
             <meshStandardMaterial color={COLORS.GOLD_METALLIC} metalness={1} roughness={0.1} />
          </mesh>
           <mesh position={[0, -armLength * 0.6, 0]} rotation={[0, 0, Math.PI / 4]}>
             <boxGeometry args={[armWidth, 0.5, armDepth]} />
             <meshStandardMaterial color={COLORS.GOLD_METALLIC} metalness={1} roughness={0.1} />
          </mesh>
          <mesh position={[0, -armLength * 0.6, 0]} rotation={[0, 0, -Math.PI / 4]}>
             <boxGeometry args={[armWidth, 0.5, armDepth]} />
             <meshStandardMaterial color={COLORS.GOLD_METALLIC} metalness={1} roughness={0.1} />
          </mesh>
        </group>
      ))}
      
      <pointLight distance={5} intensity={5} color={COLORS.GOLD_HIGHLIGHT} />
    </group>
  );
};

export default TopStar;