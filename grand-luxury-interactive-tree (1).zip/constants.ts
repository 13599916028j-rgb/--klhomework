import * as THREE from 'three';

export const COLORS = {
  EMERALD_DEEP: "#022D16",
  EMERALD_LIGHT: "#105c32",
  GOLD_METALLIC: "#D4AF37",
  GOLD_HIGHLIGHT: "#FFD700",
  RED_VELVET: "#8a0000",
  WHITE_SILK: "#f0f0f0",
  POLAROID_WHITE: "#FAFAFA",
  POLAROID_DARK: "#111111",
};

export const CONFIG = {
  // Reduced foliage count slightly to ensure smooth MediaPipe tracking
  FOLIAGE_COUNT: 35000, 
  ORNAMENT_COUNT: 400,
  PHOTO_COUNT: 40,
  TREE_HEIGHT: 12,
  TREE_RADIUS: 4.5,
  ANIMATION_DURATION: 2.5, // seconds for full transition
  BLOOM_THRESHOLD: 0.6,
  BLOOM_INTENSITY: 1.5,
};

export const ORNAMENT_TYPES = [
  { type: 'gift', weight: 0.05, scale: 0.5, colors: [COLORS.GOLD_METALLIC, COLORS.RED_VELVET] },
  { type: 'orb', weight: 0.08, scale: 0.18, colors: [COLORS.GOLD_HIGHLIGHT, COLORS.WHITE_SILK, COLORS.RED_VELVET] },
  { type: 'light', weight: 0.12, scale: 0.12, colors: [COLORS.GOLD_HIGHLIGHT] },
];